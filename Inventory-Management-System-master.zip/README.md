# Inventory Management System
An Inventory Management System using AdminLTE template and PHP

AdminLTE is a free ADMIN Panel available on the WEB. From the UI available in the Template and using PHP and Mysql Made this Admin Panel for a client.

This is a full fledged Inventory Managment System
