<?php 

$form1 = "<!DOCTYPE html>
<
 <head></head>
 <body>
<h1> Testing print function  and </h1>
 
 </body></html>" ;
?>